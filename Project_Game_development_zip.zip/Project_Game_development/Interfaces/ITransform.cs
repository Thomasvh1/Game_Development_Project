﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Project_Game_development.Interfaces
{
    public interface ITransform
    {
        Vector2 Position { get; set; }
    }
}
